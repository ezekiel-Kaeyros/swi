import RoutePreparation from '@/app/modules/route-preparation/RoutePreparation';

export default function Home({}) {
  return <RoutePreparation />; 
}
